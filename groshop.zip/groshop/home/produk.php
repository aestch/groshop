<?php
  session_start();
  if (!isset($_SESSION['status'])) {
    header("Location:../login/index.php");
    exit();
  }


  require "../login/koneksi.php";


  $queryKategori = mysqli_query($koneksi, "SELECT * FROM data_kategori");
  $kategori = mysqli_fetch_array($queryKategori);
  
  if ($_GET['keyword']) {
      $queryProduk = mysqli_query($koneksi, "SELECT * FROM data_produk WHERE nama_produk LIKE '%$_GET[keyword]%'");
  } else if ($_GET['kategori']) {
      $queryGetKategoriId = mysqli_query($koneksi, "SELECT * FROM data_kategori WHERE id_kategori = '$_GET[kategori]'");
      $kategoriId = mysqli_fetch_array($queryGetKategoriId);
      $queryProduk = mysqli_query($koneksi, "SELECT * FROM data_produk WHERE id_kategori = '$kategoriId[id_kategori]'");
  } else {
      $queryProduk = mysqli_query($koneksi, "SELECT * FROM data_produk");
  }
  ?>
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>GroShop - TIM 2 TRPL 1A MALAM</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" />
    <link rel="stylesheet" href="main.css" />
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>

</head>

<body>

    <?php require "navbar.php" ?>

    <div class="container text-center" style="margin-top: 7rem;">
        <h3 class="text-center mb-5 mt-3" id="daftar">Halaman <span> Produk </span></h3>


        <div class="row">
        <?php while ($produk = mysqli_fetch_array($queryProduk)){ ?>
          <div class="col-md-3 mb-5">
            <div class="card" style="width: 25rem; border-radius: 2rem;">
                <?php echo '<img src="data:image/jpeg;base64, '.base64_encode($produk['foto']).'" class="card-img-top p-4" style="witdh:10rem; height:25rem;"/>'; ?>
                <div class="card-body">
                    <h5 class="card-title fs-2 fw-semibold"><?php echo $produk['nama_produk']; ?> </h5>
                    <p class="card-text fs-4"><?php echo $produk['deskripsi']; ?> </p>
                    <p class="card-text fs-3 fw-bold">Rp. <?php echo number_format($produk['harga_produk'], 0, ',', '.'); ?></p>
                    <a href="../daftar-belanja/keranjang.php?id_produk=<?php echo $produk['id_produk']; ?>&aksi=tambah_produk&jumlah=1" class="btn btn-primary fs-3 mb-3" onclick="tambahkanProduk(<?php echo $produk['id_produk']; ?>)">Tambahkan</a>
                </div>
            </div>
          </div>
        <?php } ?>
        </div>
        

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>

    <script>
        function tambahkanProduk(idProduk) {
            // Lakukan tindakan yang diperlukan (misalnya, logika menambahkan ke keranjang di sini)

            // Munculkan notifikasi SweetAlert
            Swal.fire({
                icon: 'success',
                title: 'Produk berhasil ditambahkan',
                showConfirmButton: false,
                timer: 1500, // Notifikasi selama 3 detik
                background: '#28a745',
                text: '',
                toast: true,
                position: 'mid',
                customClass: {
                    popup: 'colored-toast'
                }
            }).then(() => {
                // Arahkan pengguna ke halaman daftar-belanja setelah 3 detik
                window.location.href = '../daftar-belanja/keranjang.php';
            });
        }
    </script>
</body>

</html>
