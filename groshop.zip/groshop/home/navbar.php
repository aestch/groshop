<?php
  // Pastikan session sudah dimulai di file yang memanggil script ini

  require "../login/koneksi.php";

  // Ganti sesuai dengan nama session yang digunakan untuk menyimpan ID pengguna
  $session_name = 'email';

  // Inisialisasi array untuk menyimpan nama pengguna yang sedang login
  $nama_pengguna_arr = [];

  // Periksa apakah pengguna sudah login
  if (isset($_SESSION[$session_name])) {
    $user_id = $_SESSION[$session_name];

    // Query untuk mendapatkan data pengguna berdasarkan ID
    $sel = "SELECT * FROM data_pengguna WHERE email = '$user_id'";
    $query = mysqli_query($koneksi, $sel);
    
    if ($query) {
      // Ambil hasil query
      $result = mysqli_fetch_assoc($query);
      
      // Tampilkan nama pengguna di navbar
      $nama_pengguna = $result['nama'];
      
      // Simpan nama pengguna ke dalam array
      $nama_pengguna_arr[] = $nama_pengguna;
    }
  }
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>GroShop - TIM 2 TRPL 1A MALAM</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.css" />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"
    />
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css"
    />
    <link rel="stylesheet" href="main.css"/>
  </head>

  <body>
    <header class="header">
      <a href="../home/index.php" class="logo"><i class="fas fa-shopping-basket"></i>GroShop</a>

      <nav class="navbar">
        <form method="GET" action="../home/produk.php" class="search-form">
          <input class="form-control" style="margin : 1rem; border: none;" type="search" id="search-box" name="keyword" placeholder="Cari Bahan Belanja disini....">
          <button type="submit" for="search-box" class="fa fa-search" id="searchbtn"></button>
        </form>
      </nav>


        <div class="icons">
          <div class="fas fa-search" id="search-btn"></div>
          <a href="../daftar-belanja/keranjang.php"><div class="fas fa-shopping-cart" id="cart-btn"><span class="position-absolute top-0 start-100 translate-middle badge border border-light rounded-circle bg-danger p-2"></span></div></a>

          <a class="btn btn-secondary btn-lg p-3 dropdown-toggle" style="margin-top : -0.5rem; margin-left : 1rem;" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            <font style="vertical-align: inherit;">
            <font style="vertical-align: inherit;" class="fas fa-user"></font>
            <?php echo $result[ 'nama']; ?>
            </font>
          </a>
          <ul class="dropdown-menu" >
            <li><center><b>Anggran</b></center></li>
            <center><b>Rp. <?php echo $result[ 'anggaran']; ?></b></center>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="../login/logout.php"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><b>Log Out</b></font></font></a></li>
          </ul>
        </div>
    </header>

    <script >
      let navbar = document.querySelector(".navbar");

      document.querySelector("#search-btn").onclick = () =>{
          navbar.classList.toggle("active");
      }

      window.onscroll = () =>{

          navbar.classList.remove("active");
      }
    </script>
  </body>
</html>
