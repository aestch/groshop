<!DOCTYPE html>
<html lang="en">
 
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="style.css">
  <title>Document</title>
  
</head>
 
<body style="background: #fd7e14;">

  <div class="container">
    <form id="contact" action="mail.php" method="post">
      <div class="card shadow col-4 offset-4 mt-5"><br>
        <div class="card-body">
            <h2 class="card-title text-center mb-3" style="margin-top: 10px;">Ketik saran dan masukan anda disini!!</h2>
            <input type="text" name="name" class="form-control mb-3" required placeholder="Nama Anda">
            <input type="email" name="email" class="form-control mb-3" required placeholder="Email">
            <input type="text" name="subject" class="form-control mb-3" required placeholder="Subject">
            <textarea type="text" name="message" class="form-control mb-3" placeholder="Saran & masukan anda" tabindex="5"></textarea>
            <center><button type="submit" name="send" id="contact-submit">Kirim</button></center>
            <div class="signup_link">Kembali ke halaman utama?
                <a href="../home/index.php">Home</a>
            </div>
        </div>
    </div>
      
    </form>
  </div>
  
</body>
 
</html>