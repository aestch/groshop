<?php
include 'koneksi.php';
session_start();

$email = $_POST['email'];
$kata_sandi = $_POST['kata_sandi'];

$data = mysqli_query($koneksi, "SELECT * FROM data_pengguna where email='$email' limit 1");
$cek = mysqli_num_rows($data);
$data_pengguna = mysqli_fetch_assoc($data); 

echo $cek;


if ($cek > 0) {
    
    if (password_verify($kata_sandi, $data_pengguna['kata_sandi'])) {

        if ( $data_pengguna['peran'] == 'admin' ) { 
            header('location :../groshop/halAdmin/');
        }else{

            $_SESSION['email'] = $email;
            $_SESSION['status'] = "login";
            
            echo '<link rel="stylesheet" href="../sweetalert2.min.css"></script>';
            echo '<script src="../sweetalert2.min.js"></script>';
            echo "<script>
    setTimeout(function () { 
        swal.fire({
            
            title               : 'berhasil',
            text                :  'login berhasil',
            //footer              :  '',
            icon                : 'success',
            timer               : 2000,
            showConfirmButton   : true
        });  
    },10);   setTimeout(function () {
        window.location.href = '../home/index.php'; //will redirect to your blog page (an ex: blog.html)
    }, 2000); //will call the function after 2 secs
    </script>";
        }

    } else {
        header('location:index.php?pesan=gagal2');
        // Kembali ke halaman login
    }

} else {
    header('location:index.php?pesan=gagal');
}


?>