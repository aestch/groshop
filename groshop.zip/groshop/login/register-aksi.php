<?php
include 'koneksi.php';

if (isset($_POST['daftar=']));
$nama = $_POST['nama'];
$email = $_POST['email'];
$password = $_POST['kata_sandi'];
$hp = $_POST['nomor_hp'];
$anggaran = $_POST['anggaran'];
$peran = $_POST['peran'];
$kata_sandi = password_hash($password, PASSWORD_BCRYPT);

$dataPengguna = mysqli_query($koneksi, "insert into data_pengguna values('', '$kata_sandi', '$email', '$nama', '$hp', '$anggaran', '$peran')");


header('location:index.php');
?>