<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Grocery Shopping Organizer</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.css">
    <link rel="stylesheet" href="style.css">

    <style type="text/css">
        .open{
            font-family: 'Nunito', sans-serif;
        }
    </style>
   
</head>
<body style="background: #fd7e14;">
    <form action="register-aksi.php" method="POST">
    <div class="card shadow col-4 offset-4 mt-5"><br>
        <div class="card-body">
            <h2 class="card-title text-center mb-3" style="margin-top: 10px;">REGISTER</h2>
            <input type="text" name="nama" class="form-control mb-3" required placeholder="Nama Anda">
            <input type="email" name="email" class="form-control mb-3" required placeholder="Email">
            <input type="password" name="kata_sandi" class="form-control mb-3" required placeholder="Password">
            <input type="tel" name="nomor_hp" class="form-control mb-3" required placeholder="Nomor Telp">
            <input type="number" name="anggaran" class="form-control mb-3" required placeholder="Masukkan Anggaran">
            <select class="form-select mb-3" name="peran" id="">
                <option value="pengguna">Pengguna</option>
            </select>
            <input type="submit" class="btn btn-warning col-12" name="register" value="Register"></button>
            <div class="signup_link">Already Have Account?
                <a href="index.php">Login</a>
            </div>
        </div>
    </div>

    </form>

        <!-- Success Alert -->
    <div id="successAlert" class="success-alert">
    </div>

    <script>
        function showAlert(message) {
            var successAlert = document.getElementById('successAlert');
            successAlert.innerText = message;
            successAlert.style.display = 'block';
            setTimeout(function () {
                successAlert.style.display = 'none';
            }, 3000); // Hide the alert after 3 seconds
        }

        function validateForm() {
            var nama = document.getElementsByName('nama')[0].value;
            var email = document.getElementsByName('email')[0].value;
            var password = document.getElementsByName('kata_sandi')[0].value;
            var nomorHp = document.getElementsByName('nomor_hp')[0].value;
            var anggaran = document.getElementsByName('anggaran')[0].value;

            // Periksa apakah semua isian telah diisi
            if (nama === "" || email === "" || password === "" || nomorHp === "" || anggaran === "") {
                showAlert("Harap lengkapi semua isian formulir!");
                return false; // Menghentikan pengiriman formulir jika ada isian yang kosong
            } else {
                showAlert("Registrasi berhasil");
                return true; // Izinkan pengiriman formulir jika semua isian terisi
            }
        }
    </script>
    
</body>
</html>