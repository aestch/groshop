<?php
session_start();
if (!isset($_SESSION["status"])) {
    header("location: /login");
}

include "../login/koneksi.php";
$email = $_SESSION['email'];
$userData = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT id_pengguna,nama FROM data_pengguna WHERE email = '$email' LIMIT 1"));
$user_id = $userData["id_pengguna"];
$name = $userData["nama"];
function filterData(&$str)
{
    $str = preg_replace("/\t/", "\\t", $str);
    $str = preg_replace("/\r?\n/", "\\n", $str);
    if (strstr($str, '"'))
        $str = '"' . str_replace('"', '""', $str) . '"';
}

$fileName = "data_keranjang_pengguna_$name" . "_" . date('Y-m-d') . ".xls";
$fields = array('#', 'NAMA', 'HARGA', 'QTY', 'SUBTOTAL', 'TANGGAL MASUK KERANJANG');
$excelData = implode("\t", array_values($fields)) . "\n";
if (isset($_GET['filter']) == 'date') {
    $data_from = $_GET['from'];
    $data_to = $_GET['to'];
    $query = mysqli_query($koneksi, "SELECT dab.id_daftar, dab.id_pengguna, dab.id_produk, dap.nama_produk, dap.harga_produk, dab.jumlah, dab.waktu FROM daftar_belanjaan dab INNER JOIN data_produk dap ON dap.id_produk = dab.id_produk WHERE dab.id_pengguna = $user_id AND dab.waktu >= '$data_from' AND  dab.waktu <='$data_to'");
} else {
    $query = $koneksi->query("SELECT dab.id_daftar, dab.id_pengguna, dab.id_produk, dap.nama_produk, dap.harga_produk, dab.jumlah, dab.waktu FROM daftar_belanjaan dab INNER JOIN data_produk dap ON dap.id_produk = dab.id_produk WHERE dab.id_pengguna = $user_id ORDER BY waktu ASC");
}
if ($query->num_rows > 0) {
    // Output each row of the data
    $index = 1;
    while ($row = $query->fetch_assoc()) {
        $lineData = array($index, $row['nama_produk'], $row['harga_produk'], $row['jumlah'], $row['jumlah'] * $row['harga_produk'], $row['waktu']);
        array_walk($lineData, 'filterData');
        $excelData .= implode("\t", array_values($lineData)) . "\n";
        $index++;
    }
} else {
    $excelData .= 'No records found...' . "\n";
}

// Headers for download 
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=\"$fileName\"");

// Render excel data 
echo $excelData;

exit;



?>