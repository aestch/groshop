<?php
require "../login/koneksi.php";


$data_kategori = mysqli_query($koneksi, "SELECT * FROM data_kategori");
$data_produk = mysqli_query($koneksi, "SELECT * FROM data_produk");
$jumlah_kategori = mysqli_num_rows($data_kategori);
$jumlah_produk = mysqli_num_rows($data_produk);



?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman - Admin</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../fontawesome/css/fontawesome.min.css">
</head>



<body>
    <?php require "navbar.php"; ?>
    <div class="container mt-5">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item active" aria-current="page">
                   <i class="fas fa-home"></i> Home
                </li>
            </ol>
        </nav>
        <h2>HALLO ADMIN</h2>
        
        <div class="row text-center mt-4">
            <div class="card w-25 col-sm-6 me-3">
                <div class="card-body">
                    <h3 class="card-title">KATEGORI</h3>
                    <h5 class="card-text">Total Kategori :</h5>
                    <h4 class="card-text"><?php echo $jumlah_kategori ?></h4>
                    <a href="kategori.php" class="btn btn-primary">Lihat</a>
                </div>
            </div>
            <div class="card w-25 col-sm-6">
                <div class="card-body">
                    <h3 class="card-title">PRODUK</h3>
                    <h5 class="card-text">Total Produk :</h5>
                    <h4 class="card-text"><?php echo $jumlah_produk ?></h4>
                    <a href="produk.php" class="btn btn-primary">Lihat</a>
                </div>
            </div>
        </div>
    </div>

    <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../fontawesome/js/all.min.js"></script>
</body>
</html>