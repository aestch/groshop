<?php
require "../login/koneksi.php";

$id = $_GET['x'];

$query = mysqli_query($koneksi, "SELECT * FROM data_produk WHERE id_produk='$id'");
$data = mysqli_fetch_array($query);

$queryKategori = mysqli_query($koneksi, "SELECT * FROM  data_kategori");

function generateRandomString($length = 10)
{
  $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
  $charactersLength = strlen($characters);
  $randomString = '';
  for ($i = 0; $i < $length; $i++) {
    $randomString .= $characters[rand(0, $charactersLength - 1)];
  }
  return $randomString;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Produk Detail</title>
  <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
</head>

<body>

<?php require "navbar.php" ?>
  <div class="container mt-5">
    <h2>Detail Produk</h2>

    <div class="col-12 col-md-6">
      <form action="" method="post">
        <div>
          <label for="data_produk">Nama Produk</label>
          <input type="text" name="nama_produk" id="produk" value="<?php echo $data['nama_produk']; ?>"
            class="form-control" autocomplete="off" required>
        </div>
        <div>
          <label for="id_kategori">Kategori</label>
          <select name="id_kategori" id="id_kategori" class="form-control" required>
            <option value="<?php echo $data['id_kategori']; ?>">
              <?php echo $data['id_kategori']; ?>
            </option>
            <?php
            while ($dataKategori = mysqli_fetch_assoc($queryKategori)) {
              ?>
              <option value="<?php echo $dataKategori['id_kategori']; ?>">
                <?php echo $dataKategori['id_kategori']; ?>
              </option>
              <?php
            }
            ?>
          </select>
          <div>
            <label for="harga_produk">Harga</label>
            <input type="number" class="form-control" value="<?php echo $data['harga_produk']; ?>" name="harga_produk"
              required>
          </div>
          <label for="deskripsi">Deskripsi</label>
          <input name="deskripsi" id="deskripsi" cols="30" rows="10" class="form-control"
            value="<?php echo $data['deskripsi']; ?>">

          </input>
        </div>
        <div>
          <label for="currentFoto">Foto Produk Saat Ini : </label>
          <?php echo '<img src="data:image/jpeg;base64, ' . base64_encode($data['foto']) . '"class="card-img-top p-4" style="width: 20rem; height: 25rem;"/>'; ?>
        </div>
        <div>
          <label for="foto">Foto : </label>
          <input type="file" name="foto" id="foto" class="form-control">
        </div>
    </div>
    <div class="mt-3">
      <button type="submit" class="btn btn-primary" name="simpan">Simpan</button>
      <button type="submit" class="btn btn-danger" name="hapus">Hapus</button>
    </div>
    </form>

    <?php
    if (isset($_POST['simpan'])) {
      $nama = htmlspecialchars($_POST['nama_produk']);
      $kategori = htmlspecialchars($_POST['id_kategori']);
      $harga = htmlspecialchars($_POST['harga_produk']);
      $deskripsi = htmlspecialchars($_POST['deskripsi']);

       $target_dir = "../img/";
       $nama_file = basename($_FILES["foto"]["name"]);
       $target_file = $target_dir . $nama_file;
       $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
       $image_size = $_FILES["foto"]["size"];
       $random_name = generateRandomString(20);
       $new_name = $random_name . "." . $imageFileType;

      if ($nama == '' || $kategori == '' || $harga == '') {
        ?>
        <div class="alert alert-danger mt-3" role="alert">
          Nama, Kategori dan Harga Wajib Di Isi !
        </div>
        <?php
      } else {
        $queryUpdate = mysqli_query($koneksi, "UPDATE data_produk SET id_kategori='$kategori', 
                nama_produk='$nama', harga_produk='$harga', deskripsi='$deskripsi' WHERE id_produk =$id");
        if ($queryUpdate) {
          ?>
          <div class="alert alert-success mt-3" role="alert">
            Produk Berhasil Diupdate :)
          </div>

          <meta http-equiv="refresh" content="1; url=produk.php" />
          <?php
        } else {
          echo mysqli_error($koneksi);
        }
      }
    }




    if (isset($_POST['hapus'])) {
      $queryHapus = mysqli_query($koneksi, "DELETE FROM data_produk WHERE id_produk='$id'");

      if ($queryHapus) {
        ?>
        <div class="alert alert-primary mt-3" role="alert">
          Produk Berhasil Dihapus
        </div>

        <meta http-equiv="refresh" content="1; url=produk.php" />
        <?php
      }
    }
    ?>
  </div>
  </div>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
    integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r"
    crossorigin="anonymous"></script>
</body>

</html>