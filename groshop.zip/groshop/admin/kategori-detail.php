<?php
require "../login/koneksi.php";

    $id = $_GET['x'];

    $query = mysqli_query($koneksi, "SELECT * FROM data_kategori WHERE id_kategori='$id'");
    $data = mysqli_fetch_array($query);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Kategori</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
</head>
<body>

<?php require "navbar.php" ?>
    <div class="container mt-5">
        <h2>Detail Kategori</h2>

        <div class="col-12 col-md-6">
            <form action="" method="post">
                <div>
                <label for="data_kategori">Kategori</label>
                <input type="text" name="kategori" id="kategori" value="<?php echo $data['nama_kategori']; ?>"
                class="form-control" autocomplete="off" required>
                </div>

                <div class="mt-3 d-flex justify-content-between">
                    <button type="submit" class="btn btn-primary" name="editBtn">Ubah</button>

                </div>
            </form>

            <?php
                if(isset($_POST['editBtn'])){
                    $kategori = htmlspecialchars($_POST['kategori']);

                    if($data['nama_kategori'] == $kategori){
                        
                        ?>
                            <meta http-equiv="refresh" content="0; url=kategori.php" />
                        <?php
                    }
                    else{
                        $query = mysqli_query($koneksi, "SELECT * FROM data_kategori WHERE nama_kategori='$kategori'");
                        $jumlahData = mysqli_num_rows($query);
                        echo $jumlahData; 

                        if($jumlahData > 0){
                            ?>
                             <div class="alert alert-primary mt-3" role="alert">
                                  Kategori Sudah Ada !
                             </div>
                            <?php
                        
                        }
                        else{
                            $querySimpan = mysqli_query($koneksi, "UPDATE data_kategori SET nama_kategori='$kategori' WHERE 
                            id_kategori='$id'");
                            if ($querySimpan){
                                ?>
                                <div class="alert alert-primary mt-3" role="alert">
                                  Kategori Berhasil Dihapus !
                                </div>
                                <?php
                            }


                        }
                    }
                }
                ?>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
</body>
</html>