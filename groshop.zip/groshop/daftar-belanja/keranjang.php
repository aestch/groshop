<?php
session_start();
if (!isset($_SESSION["status"])) {
  header("location: /login");
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
  <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
  <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
  <link rel="stylesheet" href="../home/main.css" />
</head>
<body>

  <?php require "../home/navbar.php"; ?>

  <div class="container" style="margin-top:80px;">
    <?php
    if (isset($_GET['halaman'])) {
      $halaman = $_GET['halaman'];
      switch ($halaman) {
        case 'produk':
          include "produk.php";
          break;
        default:
          echo "<center><h3>Maaf. Halaman tidak di temukan !</h3></center>";
          break;
      }
    } else {
      include "./keranjang-aksi.php";
    }
    ?>
  </div>
</body>
</html>


