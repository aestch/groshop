<?php

include '../login/koneksi.php';
$email = $_SESSION['email'];
$user_id = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT id_pengguna FROM data_pengguna WHERE email = '$email' LIMIT 1"))['id_pengguna'];
date_default_timezone_set('Asia/Jakarta');

if (isset($_GET['id_produk']) && isset($_GET['jumlah'])) {
    $id_produk = $_GET['id_produk'];
    $jumlah = $_GET['jumlah'];
    $sql = "select * from data_produk where id_produk='$id_produk'";
    $query = mysqli_query($koneksi, $sql);
    $data = mysqli_fetch_array($query);
    $id_produk = $data['id_produk'];
    $nama_produk = $data['nama_produk'];
    $harga_produk = $data['harga_produk'];
    $deskripsi = $data['deskripsi'];

} else {
    $id_produk = "";
    $jumlah = 0;
}

if (isset($_GET['aksi'])) {
    $aksi = $_GET['aksi'];
    if ($aksi != 'tambah_produk') {
        $id_daftar = $_GET['id_daftar'];
        if ($aksi != 'hapus') {
            $jumlah = $_GET['jumlah'];
        }
    }
} else {
    $aksi = "";
}

switch ($aksi) {
    case "tambah_produk":

        $current_date = date("Y-m-d h:i:sa");
        $insertToDB = mysqli_query($koneksi, "INSERT INTO daftar_belanjaan ( id_pengguna, id_produk,waktu, jumlah) VALUES ($user_id, $id_produk, '$current_date', 1)");
        break;
    //Fungsi untuk menghapus item dalam cart
    case "hapus":
        $getData = mysqli_query($koneksi, "SELECT * FROM daftar_belanjaan WHERE id_daftar = $id_daftar");
        if (!empty($getData)) {
            $deleteData = mysqli_query($koneksi, "DELETE FROM daftar_belanjaan WHERE id_daftar = $id_daftar");
        } else {
            echo "Data not found !";
        }
        break;

    case "update":
        $getData = mysqli_query($koneksi, "SELECT * FROM daftar_belanjaan WHERE id_daftar = $id_daftar");
        if (!empty($getData)) {
            $update_data = mysqli_query($koneksi, "UPDATE daftar_belanjaan SET jumlah = $jumlah WHERE id_daftar = $id_daftar");
        }
        break;
}
?>
<div class="row" style="margin-top: 5rem;">
    <h2 style="margin-bottom:30px;">Keranjang Belanja</h2>
    <form action="../daftar-belanja/keranjang.php" method="get"
        style="display: flex; flex-direction: row; justify-content: around">
        <!-- <input type="hidden" name="halaman" value="keranjang-aksi"> -->
        <input type="hidden" name="filter" value="date">
        <div class="input-group date">
            From
            <input type="date" name="from" class="form-control" />
            <div class="input-group-text"><i class="fa fa-calendar"></i></div>
        </div>
        <div class="input-group date">
            To
            <input type="date" name="to" class="form-control" />
            <div class="input-group-text"><i class="fa fa-calendar"></i></div>
        </div>
        <button class="btn btn-primary bg-primary" type="submit">Filter</button>
        <a class="btn btn-warning" type="submit" href="../export/export.php">Export</a>
    </form>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>No</th>
                <th hidden>Kode</th>
                <th width="40%">Nama</th>
                <th>Harga</th>
                <th width="10%">QTY</th>
                <th>Sub Total</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $no = 0;
            $sub_total = 0;
            $total = 0;
            $total_berat = 0;

            // echo $_SESSION['email'];
            
            if (isset($_GET['filter']) == 'date') {
                $data_from = $_GET['from'];
                $data_to = $_GET['to'];
                $data_get = mysqli_query($koneksi, "SELECT dab.id_daftar, dab.id_pengguna, dab.id_produk, dap.nama_produk, dap.harga_produk, dab.jumlah, dab.waktu FROM daftar_belanjaan dab INNER JOIN data_produk dap ON dap.id_produk = dab.id_produk WHERE dab.id_pengguna = $user_id AND dab.waktu >= '$data_from' AND  dab.waktu <='$data_to'");
            } else {

                $data_get = mysqli_query($koneksi, "SELECT dab.id_daftar, dab.id_pengguna, dab.id_produk, dap.nama_produk, dap.harga_produk, dab.jumlah, dab.waktu FROM daftar_belanjaan dab INNER JOIN data_produk dap ON dap.id_produk = dab.id_produk WHERE dab.id_pengguna = $user_id");
            }


            // $processed_data = $data_get;

            // echo var_dump($processed_data->fetch_assoc());
            if (!empty($data_get)):
                foreach ($data_get as $item):
                    $no++;
                    $sub_total = $item['jumlah'] * $item['harga_produk'];
                    $total += $sub_total;
                    ?>
                    <input type="hidden" name="id_daftar" class="id_produk" value="<?php echo $item["id_daftar"]; ?>" />
                    <tr>
                        <td>
                            <?php echo $no; ?>
                        </td>
                        <td hidden>
                            <?php echo $item["id_produk"]; ?>
                        </td>
                        <td>
                            <?php echo $item["nama_produk"]; ?>
                        </td>
                        <td>Rp.
                            <?php echo number_format($item["harga_produk"], 0, ',', '.'); ?>
                        </td>
                        <td>
                            <input type="number" min="1" value="<?php echo $item["jumlah"]; ?>" class="form-control"
                                id="jumlah<?php echo $no; ?>" name="jumlah[]">
                            <script>
                                $("#jumlah<?php echo $no; ?>").bind('change', function () {
                                    var jumlah<?php echo $no; ?> = $("#jumlah<?php echo $no; ?>").val();
                                    $("#jumlaha<?php echo $no; ?>").val(jumlah<?php echo $no; ?>);
                                });
                                $("#jumlah<?php echo $no; ?>").keydown(function (event) {
                                    return false;
                                });

                            </script>

                        </td>
                        <td>Rp.
                            <?php echo number_format($sub_total, 0, ',', '.'); ?>
                        </td>

                        <td>
                            <form method="get">
                                <input type="hidden" name="id_daftar" value="<?php echo $item['id_daftar']; ?>"
                                    class="form-control">
                                <input type="hidden" name="aksi" value="update" class="form-control">
                                <!-- <input type="hidden" name="halaman" value="keranjang-aksi" class="form-control"> -->
                                <input type="hidden" name="jumlah" value="<?php echo $item["jumlah"]; ?>"
                                    id="jumlaha<?php echo $no; ?>" value="" class="form-control">
                                <input type="submit" class="btn btn-warning btn-xs" value="Update" onclick="alert('produk Berhasil di update')">
                            </form>
                            <a href="keranjang.php?id_daftar=<?php echo $item['id_daftar']; ?>&aksi=hapus"
                                class="btn btn-danger btn-xs" role="button" onclick="alert('Data Dihapus')">Delete</a>
                        </td>
                    </tr>
                    <?php
                endforeach;
            endif;
            ?>
        </tbody>
    </table>
    <h3>Total Pembayaran Rp
        <?php echo number_format($total, 0, ',', '.'); ?>
    </h3>
</div>

